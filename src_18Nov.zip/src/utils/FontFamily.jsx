export default {
  ManropeBold: "Manrope-Bold",
  ManropeExtraBold: "Manrope-ExtraBold",
  ManropeExtraLight: "Manrope-ExtraLight",
  ManropeLight: "Manrope-Light",
  ManropeMedium: "Manrope-Medium",
  ManropeRegular: "Manrope-Regular",
  ManropeSemiBold: "Manrope-SemiBold",

  // Poppins
  PoppinsBlack: "Poppins-Black",
  PoppinsBold: "Poppins-Bold",
  PoppinsExtraBold: "Poppins-ExtraBold",
  PoppinsExtraLight: "Poppins-ExtraLight",
  PoppinsLight: "Poppins-Light",
  PoppinsMedium: "Poppins-Medium",
  PoppinsRegular: "Poppins-Regular",
  PoppinsSemiBold: "Poppins-SemiBold",
  PoppinsThin: "Poppins-Thin",

  // Rubik
  RubikBlack: "Rubik-Black",
  RubikBold: "Rubik-Bold",
  RubikExtraBold: "Rubik-ExtraBold",
  RubikExtraLight: "Rubik-ExtraLight",
  RubikMedium: "Rubik-Medium",
  RubikRegular: "Rubik-Regular",
  RubikSemiBold: "Rubik-SemiBold",
};
